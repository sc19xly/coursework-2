# coursework-2
https://github.com/sc19xly/coursework-2/commits/master
![R0`I7L)ONO ~1K)HET%(92L](https://user-images.githubusercontent.com/80677732/116871716-49751f00-ac47-11eb-8c5d-a00b912d62c0.png)![@~4T(@QSE_3}9Y3A5)9Y%2B](https://user-images.githubusercontent.com/80677732/117116829-6afa1600-adc1-11eb-98f9-3f2bb9085f8a.png)


To run my programme, user needs to download all the files in the repository and use make command. Then user needs choose a mode and when using mouse to selfdeifne the initial state, user needs to press e to enter the next movement.
When the cells is evoloving, the user can press p to pause and press p again to continue, press e to exit the programme.
To test the programme, user needs to downloda the test folider and use make command to test each function.
